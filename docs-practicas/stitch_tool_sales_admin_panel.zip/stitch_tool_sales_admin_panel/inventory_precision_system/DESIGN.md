---
name: Inventory Precision System
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  h1:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-xs:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 2rem
  gutter: 1.5rem
  section-gap: 2rem
  element-gap-sm: 0.5rem
  element-gap-md: 1rem
---

## Brand & Style

This design system is built on a foundation of **Modern Minimalism**, prioritizing utility and clarity for high-frequency inventory management. Drawing inspiration from `shadcn/ui` and Radix Primitives, the aesthetic is "invisible"—it stays out of the way of the data while providing a premium, engineered feel.

The brand personality is authoritative yet accessible, evoking a sense of organized efficiency. It avoids unnecessary decoration, instead using generous whitespace and a rigorous grid to establish hierarchy. The emotional response should be one of "calm control," ensuring that users managing hundreds of assets feel supported by a stable, predictable interface.

## Colors

The palette is anchored in **Slate and Gray**, providing a neutral, professional backdrop that reduces eye strain during long sessions. 

- **Primary Actions:** A vibrant Blue (#2563eb) is reserved strictly for primary calls-to-action, status indicators for "active" items, and focused states.
- **Surface & Backgrounds:** The system uses a tiered white-to-gray scale. The main background is pure white, while sidebars and secondary containers use a subtle slate tint (#f8fafc) to provide structural separation.
- **Borders:** Subtle borders (#e2e8f0) are the primary method of containment, replacing heavy shadows to maintain a flat, modern look.
- **Feedback:** Success (Emerald), Destructive (Rose), and Warning (Amber) are used sparingly in low-saturation variants to ensure they don't overpower the slate-driven hierarchy.

## Typography

This design system utilizes **Inter** for all roles, capitalizing on its exceptional legibility in data-dense environments. 

- **Hierarchy:** We use weight (SemiBold 600) rather than drastic size changes to differentiate headers. This keeps the dashboard feeling compact and efficient.
- **Data Tables:** For inventory lists, `body-sm` (14px) is the standard to allow for maximum information density without sacrificing readability.
- **Tracking:** Headings use slight negative letter-spacing (-0.01em to -0.02em) to appear more cohesive and "premium."
- **Labels:** Small labels use Medium (500) weight to remain legible against slate backgrounds.

## Layout & Spacing

The design system employs a **Fixed-Fluid Hybrid** layout. 
- **Sidebar:** Fixed at 280px for navigation.
- **Main Content:** Fluid width with a maximum container cap of 1440px to prevent line lengths from becoming unreadable on ultra-wide monitors.
- **Grid:** A 12-column system is used for dashboard widgets. Cards typically span 3, 4, or 6 columns.
- **Rhythm:** An 8px linear scale (using 4px increments for tight components) governs all padding and margins. Generous page margins (32px) ensure the interface feels airy despite the technical nature of the content.

## Elevation & Depth

To maintain a minimalist aesthetic, this design system relies on **Tonal Layers and Low-Contrast Outlines** rather than traditional shadows.

- **Level 0 (Background):** Base canvas in white (#ffffff).
- **Level 1 (Cards/Sidebar):** Defined by a 1px border (#e2e8f0). No shadow.
- **Level 2 (Dropdowns/Modals):** These are the only elements that receive a shadow. We use a "Soft Ambient Shadow": `0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)`.
- **Interactive States:** Hovering over a list item or card should trigger a subtle background color change to Slate-50 (#f8fafc) rather than an elevation lift.

## Shapes

The shape language is "Geometric-Soft." We use a consistent corner radius to soften the technical data and make the tool inventory feel modern and approachable.

- **Small Components (Buttons, Inputs):** 8px radius.
- **Containers (Cards, Modals):** 12px radius.
- **Inner Elements:** When an element sits inside a container (e.g., an image inside a card), its radius should be 4px smaller than the parent to maintain visual nesting harmony.

## Components

- **Buttons:** Primary buttons use a solid Blue-600 background with white text. Secondary buttons use a Slate-100 background or a simple 1px border. 
- **Inputs:** Focus states are indicated by a 2px blue ring with an offset, mimicking the `shadcn/ui` focus-visible behavior.
- **Status Chips:** Used for "In Stock," "Checked Out," or "Under Maintenance." These use a "soft pill" style: low-saturation background with high-saturation text (e.g., Light Green bg / Dark Green text).
- **Data Tables:** Rows have a minimum height of 48px. Use subtle horizontal dividers only. Header cells use `label-xs` with Slate-500 text.
- **Inventory Cards:** These should include a small thumbnail slot with an 8px radius, a bold title, and a secondary text line for the SKU or Serial Number.
- **Empty States:** Use a light slate icon and centered `body-sm` text to guide the user when no tools are found in a category.